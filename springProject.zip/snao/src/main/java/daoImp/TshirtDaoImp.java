package daoImp;

import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.log4j.Logger;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import dao.Dao;
import dao.TshirtDao;
import dto.Tshirt;


public class TshirtDaoImp implements TshirtDao{

	final static Logger LOG = Logger.getLogger(TshirtDaoImp.class);

	@Autowired
	private Dao dao;

	/**
	 * This method adds a flight object to the Flight table in database.
	 */
	public void addTshirt(Tshirt tshirt) {
		LOG.info("Adding new Tshirt : " + tshirt.getId());

		dao.begin();

		dao.getSession().save(tshirt);

		dao.commit();
		dao.close();

		LOG.info(tshirt.getId() + " Tshirt added successfully.");
	}

	/**
	 * This method searches for flights that match the method parameters i.e. the
	 * user input. predicate is an array of all the restriction that are used to
	 * filter the flights according to user input.
	 */
	public List<Tshirt> getTshirts(String color, String size, String gender) {
		LOG.info("Searching for flights according to user's input.");

		dao.begin();

		CriteriaBuilder criteriaBuilder = dao.getSession().getCriteriaBuilder();
		CriteriaQuery<Tshirt> criteriaQuery = criteriaBuilder.createQuery(Tshirt.class);
		Root<Tshirt> root = criteriaQuery.from(Tshirt.class);

		Predicate[] predicates = new Predicate[3];

		predicates[0] = criteriaBuilder.equal(root.get("color"), color);
		predicates[1] = criteriaBuilder.equal(root.get("size"), size);

		//Path<Date> flightDatePath = root.get("flightDat
		predicates[2] = criteriaBuilder.equal(root.get("gender"),gender);

		//ParameterExpression<String> p = criteriaBuilder.parameter(String.class, "flightClass");
		//predicates[3] = criteriaBuilder.like(root.<String>get("flightClass"), "%" + flightClass + "%");

		criteriaQuery.select(root).where(predicates);
		
		Query<Tshirt> query = dao.getSession().createQuery(criteriaQuery);
		List<Tshirt> searchResult = query.getResultList();

		dao.commit();
		dao.close();

		return searchResult;
	}

	/**
	 * This method fetches distinct toAirportCodes i.e. Arrival Location.
	 * 
	 * @return List of distinct Arrival Locations
	 */
	public List<String> getColors() {
		LOG.info("Retrieving distinct Colors.");

		List<String> colors;

		dao.begin();
		CriteriaBuilder criteriaBuilder = dao.getSession().getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Tshirt> root = criteriaQuery.from(Tshirt.class);
		criteriaQuery.multiselect(root.get("color")).distinct(true);

		colors = dao.getSession().createQuery(criteriaQuery).getResultList();

		return colors;
	}

	/**
	 * This method fetches distinct fromAirportCodes i.e. Departure Location.
	 * 
	 * @return List of distinct Departure locations.
	 */
	public List<String> getSizes() {
		LOG.info("Retrieving distinct Sizes.");

		List<String> sizes;

		dao.begin();
		CriteriaBuilder criteriaBuilder = dao.getSession().getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Tshirt> root = criteriaQuery.from(Tshirt.class);
		criteriaQuery.multiselect(root.get("size")).distinct(true);

		sizes = dao.getSession().createQuery(criteriaQuery).getResultList();

		return sizes;
	}
	public List<String> getGenders() {
		LOG.info("Retrieving distinct Genders.");

		List<String> genders;

		dao.begin();
		CriteriaBuilder criteriaBuilder = dao.getSession().getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<Tshirt> root = criteriaQuery.from(Tshirt.class);
		criteriaQuery.multiselect(root.get("gender")).distinct(true);

		genders = dao.getSession().createQuery(criteriaQuery).getResultList();

		return genders;
	}

}
