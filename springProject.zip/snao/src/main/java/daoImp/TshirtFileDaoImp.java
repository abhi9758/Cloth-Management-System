package daoImp;


import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.springframework.beans.factory.annotation.Autowired;

import dao.Dao;
import dao.TshirtFileDao;
import dto.TshirtFile;

public  class TshirtFileDaoImp implements TshirtFileDao {

	final static Logger LOG = Logger.getLogger(TshirtFileDaoImp.class);

	@Autowired
	Dao dao;

	public List<TshirtFile> getAllTshirtFiles() {
		LOG.info("Retrieving all FlightFile object of read files.");

		dao.begin();

		Criteria criteria = dao.getSession().createCriteria(TshirtFile.class);
		List<TshirtFile> tshirtFiles = (List<TshirtFile>) criteria.list();

		dao.commit();
		dao.close();

		LOG.info("Retrieved all FlightFile objects of read files successfully.");
		return tshirtFiles;
	}

	public TshirtFile getTshirtFile(String fileName) {
		LOG.info("Retrieving FlightFile object of : " + fileName);

		dao.begin();

		TshirtFile tshirtFile = (TshirtFile) dao.getSession().get(TshirtFile.class, fileName);

		dao.commit();
		dao.close();
		
		LOG.info("Retrieved FlightFile object of " + fileName + " successfully.");
		return tshirtFile;
	}

	public void updateTshirtFile(TshirtFile tshirtFile) {
		LOG.info("Updating FlightFile object of " + tshirtFile.getFileName());
		
		dao.begin();

		dao.getSession().update(tshirtFile);

		dao.commit();
		dao.close();
		
		LOG.info("Updated FlightFile object of " + tshirtFile.getFileName() + " successfully.");
	}

	public void addTshirtFile(TshirtFile newTshirtFile) {
		LOG.info("Adding FlightFile object of " + newTshirtFile.getFileName());
		
		dao.begin();

		dao.getSession().save(newTshirtFile);

		dao.commit();
		dao.close();

		LOG.info("Added FlightFile object of " + newTshirtFile.getFileName() + " successfully.");
	}

	

	

}
