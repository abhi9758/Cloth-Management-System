package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dto.Tshirt;
import service.TshirtSearchService;
import service.OutputPreferanceService;

@Controller
public class SearchController {

	@Autowired
	private TshirtSearchService tshirtSearch;
	
	@Autowired
	private OutputPreferanceService outputPreferance;

	@RequestMapping("/search")
	public ModelAndView searchFlights(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();

		String Color = request.getParameter("color").toString();
		String Size = request.getParameter("size").toString();
		String Gender = request.getParameter("gender").toString();
		//String flightClass = request.getParameter("class").toString();
		int sortBy = Integer.parseInt(request.getParameter("sortBy").toString());
		
		List<Tshirt> searchResult = tshirtSearch.getSearchResult(Color, Size, Gender);
		outputPreferance.sortFlights(searchResult, sortBy);
		
		
		mv.addObject("searchResult", searchResult);
		mv.setViewName("result");
		return mv;
	}

}
