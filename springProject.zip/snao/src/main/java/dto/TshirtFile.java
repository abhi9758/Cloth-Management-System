package dto;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Tshirt_files")
public class TshirtFile {
	private String fileName;
	private int rows;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getRows() {
		return rows;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}
	@Override
	public boolean equals(Object obj) {
		TshirtFile tshirtFile = (TshirtFile) obj;
		return this.getFileName().equals(tshirtFile.getFileName());
	}
}
