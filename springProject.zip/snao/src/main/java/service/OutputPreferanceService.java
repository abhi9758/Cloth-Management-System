package service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dto.Tshirt;

/**
 * OutputPreferance class sorts the search result according to the user's
 * preference.
 * 
 * @author sahilmehta02
 *
 */
@Service
public class OutputPreferanceService {

	final static Logger LOG = Logger.getLogger(OutputPreferanceService.class);

	@Autowired
	private TshirtComparatorService tshirtComparator;

	/**
	 * Sorts flights collection by user's output preference after retrieving
	 * appropriate comparator from FlightComparator class.
	 * 
	 * @param searchResult List of Flights matching user's input.
	 * @param sortBy       user's output preference.
	 */
	public void sortFlights(List<Tshirt> searchResult, int sortBy) {
		LOG.info("Sorting search result according to output preference.");

		Comparator<Tshirt> comparator;

		if (sortBy == 1) 
		{
			comparator = tshirtComparator.getTshirtComparatorbyPrice();
			Collections.sort(searchResult, comparator);
		} else if(sortBy == 2) 
		{
			comparator = tshirtComparator.getTshirtComparatorbyRating();
			Collections.sort(searchResult, comparator);
		}
		else
		{
			comparator = tshirtComparator.getTshirtComparatorbyBoth();
			Collections.sort(searchResult, comparator);
		}

	}
}
