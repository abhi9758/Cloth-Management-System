package service;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import constants.Constants;
import dao.TshirtDao;
import dao.TshirtFileDao;
import dto.Tshirt;
import dto.TshirtFile;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

/**
 * FlightLoader class loads flights from CSV files to the mySQL database. It
 * periodically checks for new flights and adds it to database when found.
 * 
 * @author sahilmehta02
 *
 */
public class TshirtLoaderService {

	@Autowired
	TshirtFileDao tshirtFileDao;

	@Autowired
	TshirtDao tshirtDao;

	final static Logger LOG = Logger.getLogger(TshirtLoaderService.class);

	private File folder = new File(Constants.FOLDERPATH);
	private File[] folderFiles;
	private List<TshirtFile> dbFiles;
	private FileReader fileReader;
	private CSVParser parser = new CSVParserBuilder().withSeparator('|').build();
	private CSVReader csvReader;

	/**
	 * This method is executed periodically to check for new flights and update
	 * database if any new flights are found. dbFiles is list of FLightFile objects
	 * from the database that are the objects of CSV files that are read already.
	 * folderFiles is a array of File objects of CSV files that are currently
	 * present in the target folder.
	 */
	@Scheduled(fixedRate = 7000, initialDelay = 5000)
	public void loadTshirts() {

		LOG.info("Starting flight loading process. \n \n");

		dbFiles = tshirtFileDao.getAllTshirtFiles();
		folderFiles = folder.listFiles();

		checkNewTshirts();

		LOG.info("Flight loading process completed successfully. \n \n");
	}

	/**
	 * This method checks for new Flights by comparing dbFiles and folderFiles.
	 * Unmatched files are new files which are then loaded. Matched files are
	 * checked for new entries.
	 */
	private void checkNewTshirts() {
		LOG.info("Checking for new Tshirts.");

		for (File folderFile : folderFiles) {

			TshirtFile folderTshirtFile = new TshirtFile();
			folderTshirtFile.setFileName(folderFile.getName());

			LOG.info("Checking for new files.");
			if (!dbFiles.contains(folderTshirtFile)) {
				readTshirtsFromFile(folderTshirtFile, folderFile);
			} else {
				LOG.info("No new files found.");
				checkForNewEntriesInFile(folderTshirtFile, folderFile);
			}
		}
	}

	/**
	 * This method creates flight object of entries present in the newly found CSV
	 * file and persist it in database. Also the a FlightFile object of the new CSV
	 * file is created that stores file name and number of rows read.
	 * 
	 * @param folderflightFile
	 * @param folderFile
	 */
	private void readTshirtsFromFile(TshirtFile folderTshirtFile, File folderFile) {
		LOG.info("============== > New file found : " + folderTshirtFile.getFileName() + " < ============");
		try {

			fileReader = new FileReader(folderFile);
			csvReader = new CSVReaderBuilder(fileReader).withCSVParser(parser).build();
			List<String[]> allTshirtData = csvReader.readAll();
			int noOfEntries = allTshirtData.size() - 1;

			for (int rowNumber = 1; rowNumber < allTshirtData.size(); rowNumber++) {
				Tshirt newTshirt = createTshirtObject(allTshirtData.get(rowNumber));
				tshirtDao.addTshirt(newTshirt);
			}

			folderTshirtFile.setRows(noOfEntries);
			tshirtFileDao.addTshirtFile(folderTshirtFile);

		} catch (FileNotFoundException fileNotFoundException) {
			LOG.error("File not found : " + folderFile.getName());

		} catch (IOException ioException) {
			LOG.error("Input Output Exception occured while reading : " + folderFile.getName());

		} catch (Exception exception) {
			LOG.fatal("Unknown Exception occured while reading : " + folderFile.getName());
		}

	}

	/**
	 * This method compares the number of rows present in the matching files. In
	 * case new rows are found it creates the Flight object of that row and persist
	 * it in Flight table. Also the FlightFile object is updated and persisted.
	 * 
	 * @param folderflightFile
	 * @param folderFile
	 */
	private void checkForNewEntriesInFile(TshirtFile folderTshirtFile, File folderFile) {
		LOG.info("Checking for new entries in existing file : " + folderTshirtFile.getFileName());

		try {

			fileReader = new FileReader(folderFile);
			csvReader = new CSVReaderBuilder(fileReader).withCSVParser(parser).build();
			List<String[]> allTshirtData = csvReader.readAll();
			int noOfEntries = allTshirtData.size() - 1;

			TshirtFile dbTshirtFile = (TshirtFile) tshirtFileDao.getTshirtFile(folderTshirtFile.getFileName());
			int noOfEntriesDB = dbTshirtFile.getRows();

			if (noOfEntriesDB != noOfEntries) {
				LOG.info("========= >> New entries found in file : " + folderTshirtFile.getFileName() + " << =========");

				for (int rowNumber = 1 + noOfEntriesDB; rowNumber < allTshirtData.size(); rowNumber++) {
					Tshirt newTshirt = createTshirtObject(allTshirtData.get(rowNumber));
					tshirtDao.addTshirt(newTshirt);
				}

				folderTshirtFile.setRows(noOfEntries);
				tshirtFileDao.updateTshirtFile(folderTshirtFile);
			} else {
				LOG.info("No new Tshirt found in " + folderFile.getName());
			}

		} catch (FileNotFoundException fileNotFoundException) {
			LOG.error("File not found : " + folderFile.getName());

		} catch (IOException ioException) {
			LOG.error("Input Output Exception occured while reading : " + folderFile.getName());

		} catch (Exception exception) {
			LOG.fatal("Unknown Exception occured while reading : " + folderFile.getName());
		}
	}

	/**
	 * This method creates a Flight object of a row from CSV file.
	 * 
	 * @param flightData CSV file row data.
	 * @return Flight object
	 */
	private Tshirt createTshirtObject(String[] tshirtData) {
		Tshirt tshirt = new Tshirt();
		tshirt.setId(tshirtData[0]);
		tshirt.setName(tshirtData[1]);
		tshirt.setColor(tshirtData[2]);
		tshirt.setGender(tshirtData[3]);
		tshirt.setSize(tshirtData[4]);
		tshirt.setPrice(Float.parseFloat(tshirtData[5]));
		tshirt.setRating(Float.parseFloat(tshirtData[6]));
		tshirt.setAvailability(tshirtData[7]);
		return tshirt;
	}
}
