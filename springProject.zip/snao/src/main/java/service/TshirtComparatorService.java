package service;


import java.util.Comparator;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import dto.Tshirt;

/**
 * FlightComparator class generates Comparator according to user's output
 * preference.
 * 
 * @author sahilmehta02
 *
 */

@Service
public class TshirtComparatorService {

	final static Logger LOG = Logger.getLogger(TshirtComparatorService.class);

	/**
	 * This method creates and returns a Comparator that sorts the flights by fare.
	 * 
	 * @return Comparator class that sort by fare.
	 */
	public Comparator<Tshirt> getTshirtComparatorbyPrice() {
		LOG.info("Creating Comparator to by sort by Price.");

		return (tshirt1, tshirt2) -> {
			//return Double.compare(tshirt1.get(), flight2.getFare());
			Float price1 = Float.valueOf(tshirt1.getPrice());
            Float price2 = Float.valueOf(tshirt2.getPrice());
            return price1.compareTo(price2);
		};

	}

	/**
	 * This method creates and returns a Comparator that sorts the flights by fare
	 * and flight duration.
	 * 
	 * @return Comparator class that sort by fare and flight duration.
	 */
	public Comparator<Tshirt> getTshirtComparatorbyRating() {
		LOG.info("Creating Comparator to by sort by Rating.");

		return (tshirt1, tshirt2) -> {
			Float rating1 = Float.valueOf(tshirt1.getRating());
            Float rating2 = Float.valueOf(tshirt2.getRating());
            return rating1.compareTo(rating2);
		};
		
	}
	public Comparator<Tshirt> getTshirtComparatorbyBoth() {
		LOG.info("Creating Comparator to by sort by Both.");
		
		//Comparator<Tshirt> getTshirtComparatorbyPrice() {
			//LOG.info("Creating Comparator to by sort by Price.");

			return (tshirt1, tshirt2) -> {
				//return Double.compare(tshirt1.get(), flight2.getFare());
				Float price1 = Float.valueOf(tshirt1.getPrice());
	            Float price2 = Float.valueOf(tshirt2.getPrice());
	            return price1.compareTo(price2);
			};

		}
		/*Comparator<Tshirt> getTshirtComparatorbyRating() {
			LOG.info("Creating Comparator to by sort by Rating.");

			return (tshirt1, tshirt2) -> {
				Float rating1 = Float.valueOf(tshirt1.getRating());
	            Float rating2 = Float.valueOf(tshirt2.getRating());
	            return rating1.compareTo(rating2);
			};
			
		}*/
		
	}

