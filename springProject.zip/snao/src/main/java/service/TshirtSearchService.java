package service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.TshirtDao;
import dto.Tshirt;


/**
 * FlightSearch class searches flights according to user's input.
 * 
 * @author sahilmehta02
 *
 */
@Service
public class TshirtSearchService {

	@Autowired
	private TshirtDao tshirtdao;

	/**
	 * This method takes in arguments from the controller method and passes it to
	 * the dao layer to get the list of matching flights.
	 * 
	 * @param arrivalLocation
	 * @param departLocation
	 * @param date
	 * @param flightClass
	 * @return List of matching flights.
	 */
	public List<Tshirt> getSearchResult(String color, String size, String gender) 
	{
		List<Tshirt> searchResult;

		//Date flightDate = DateParser.getDate(date);

		searchResult = tshirtdao.getTshirts(color, size, gender);

		return searchResult;
	}

}
