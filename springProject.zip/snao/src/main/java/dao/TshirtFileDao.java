package dao;


import java.util.List;

import dto.TshirtFile;

public interface TshirtFileDao {
	
	public List<TshirtFile> getAllTshirtFiles();
	public TshirtFile getTshirtFile(String fileName);
	public void updateTshirtFile(TshirtFile tshirtFile);
	public void addTshirtFile(TshirtFile newTshirtFile);
	
}
