package dao;

import dto.User;

public interface UserDao {

	public void saveUser(User user);
	public User getUser(String uId);
}
