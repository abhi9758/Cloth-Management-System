package dao;


import java.util.List;

import dto.Tshirt;

public interface TshirtDao {

	public void addTshirt(Tshirt tshirt);

	public List<Tshirt> getTshirts(String color, String size,  String gender);
	
	public List getColors();
	
	public List getSizes();
	
	public List getGenders();
}
