package configuration;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

import dao.Dao;
import dao.TshirtDao;
import dao.TshirtFileDao;
import dao.UserDao;
import daoImp.DaoImp;
import daoImp.TshirtDaoImp;
import daoImp.TshirtFileDaoImp;
import daoImp.UserDaoImp;
import service.TshirtComparatorService;
import service.TshirtLoaderService;
import service.TshirtSearchService;
import service.OutputPreferanceService;
import service.UserService;;

@Configuration
@EnableScheduling
public class AppConfig {

	@Bean
	public Dao getDao() {
		return new DaoImp();
	}
	
	@Bean
	public UserDao getUserDao() {
		return new UserDaoImp();
	}

	@Bean
	public TshirtDao getTshirtDao() {
		return new TshirtDaoImp();
	}

	@Bean
	public TshirtLoaderService getTshirtLoader() {
		return new TshirtLoaderService();
	}
	
	@Bean
	public TshirtSearchService getTshirtSearch() {
		return new TshirtSearchService();
	}

	@Bean
	public TshirtFileDao getTshirtFileDao() {
		return new TshirtFileDaoImp();
	}

	
	@Bean
	public OutputPreferanceService getOutputPreferance() {
		return new OutputPreferanceService();
	}
	
	@Bean
	public TshirtComparatorService getTshirtComparator() {
		return new TshirtComparatorService();
	}
	
	@Bean
	public UserService getUserService() {
		return new UserService();
	}

}
