package constants;

public class Constants {

	public static final String FOLDERPATH = "D:\\Projects\\Advance Java\\Advance Java\\Assigment Links";
}
